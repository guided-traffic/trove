{{/*
The Secret mounts of a pod (R-HA-030) as a YAML list. Argument: dict "root" . "scope" "runtime"
(the pods of the roles), "migrate" (the migration Job), "backup" (the backup CronJob's pods) or "restore" (the
restore Job's pod) or "post-restore" (the hook Job after a platform restore: the database login of the migration Job, the blob store, and the journal credential). Each entry names one existing Secret,
the keys that are projected and the file name each key gets. Secrets mount read-only with
defaultMode 0440, with items and without subPath, so a rotated Secret reaches the files.
Secrets never become environment variables. The login secrets (secrets.oidc, secrets.breakGlass) are
mounted into the pods of role api (the main Deployment, its pools and its endpoint pools) and, in the bridge of
R-HA-064, into the web pods; never into packages, worker or a Job. The target of the backup (secrets.backupTarget,
secrets.backupTargetCA) mounts into the backup and restore pods only (R-HA-060, R-BAK-011); Valkey into none of the Jobs
(R-BAK-012, R-BAK-022); the key ring into the replicas and the restore Job, which checks that it opens every key ID of the
backup (R-BAK-020).
*/}}
{{- define "trove.secretMounts" -}}
{{- $s := .root.Values.secrets -}}
{{- $out := list -}}
{{- $dbSecret := $s.database -}}
{{- if and (has .scope (list "migrate" "restore" "post-restore")) $s.databaseMigration.existingSecret -}}
{{- $dbSecret = $s.databaseMigration -}}
{{- else if and (eq .scope "backup") $s.databaseBackup.existingSecret -}}
{{- $dbSecret = $s.databaseBackup -}}
{{- end -}}
{{- $job := has .scope (list "backup" "restore") -}}
{{- $ioJob := has .scope (list "backup" "restore" "post-restore") -}}
{{- $out = append $out (dict "name" "database" "secret" $dbSecret.existingSecret "path" "/var/run/secrets/trove/database" "items" (list (dict "key" $dbSecret.usernameKey "path" "username") (dict "key" $dbSecret.passwordKey "path" "password"))) -}}
{{- if $s.databaseCA.existingSecret -}}
{{- $out = append $out (dict "name" "database-ca" "secret" $s.databaseCA.existingSecret "path" "/var/run/secrets/trove/database-ca" "items" (list (dict "key" $s.databaseCA.key "path" "ca.crt"))) -}}
{{- end -}}
{{- /* The trusted CA bundle (R-HA-043) reaches every pod that reads the shared configuration file, because its paths are in it: the roles and all Jobs. A public certificate, never a key. */ -}}
{{- $ca := .root.Values.trustedCA -}}
{{- if or $ca.existingSecret $ca.existingConfigMap -}}
{{- $caItems := list -}}
{{- range $ca.keys -}}
{{- $caItems = append $caItems (dict "key" . "path" .) -}}
{{- end -}}
{{- if $ca.existingSecret -}}
{{- $out = append $out (dict "name" "trusted-ca" "secret" $ca.existingSecret "path" "/etc/trove/ca" "items" $caItems) -}}
{{- else -}}
{{- $out = append $out (dict "name" "trusted-ca" "configMap" $ca.existingConfigMap "path" "/etc/trove/ca" "items" $caItems) -}}
{{- end -}}
{{- end -}}
{{- if $s.databaseClientCert.existingSecret -}}
{{- $out = append $out (dict "name" "database-client" "secret" $s.databaseClientCert.existingSecret "path" "/var/run/secrets/trove/database-client" "items" (list (dict "key" $s.databaseClientCert.certKey "path" "tls.crt") (dict "key" $s.databaseClientCert.keyKey "path" "tls.key"))) -}}
{{- end -}}
{{- if or (eq .scope "runtime") (eq .scope "restore") -}}
{{- /* The key ring is mounted into replicas and the restore Job only: the migration Job and the backup pods never seal or open a value (R-HA-030, R-BAK-012). */ -}}
{{- $encItems := list -}}
{{- range $s.encryption.keys -}}
{{- $encItems = append $encItems (dict "key" . "path" .) -}}
{{- end -}}
{{- $out = append $out (dict "name" "encryption" "secret" $s.encryption.existingSecret "path" "/var/run/secrets/trove/encryption" "items" $encItems) -}}
{{- end -}}
{{- if or (eq .scope "runtime") $ioJob -}}
{{- if and (eq .scope "backup") (eq (dig "storage" "s3" "credentials" "source" "" .root.Values.config) "static") -}}
{{- /* The backup reads the blob bucket and never writes or deletes there (R-BAK-015): it gets the read-only login of secrets.backupSource, not the runtime credential (Q-HA-160). */ -}}
{{- $out = append $out (dict "name" "backup-source" "secret" $s.backupSource.existingSecret "path" "/var/run/secrets/trove/backup-source" "items" (list (dict "key" $s.backupSource.accessKeyIdKey "path" "access-key-id") (dict "key" $s.backupSource.secretAccessKeyKey "path" "secret-access-key"))) -}}
{{- else if eq (dig "storage" "s3" "credentials" "source" "" .root.Values.config) "static" -}}
{{- $out = append $out (dict "name" "s3" "secret" $s.s3.existingSecret "path" "/var/run/secrets/trove/s3" "items" (list (dict "key" $s.s3.accessKeyIdKey "path" "access-key-id") (dict "key" $s.s3.secretAccessKeyKey "path" "secret-access-key"))) -}}
{{- end -}}
{{- if $s.s3CA.existingSecret -}}
{{- $out = append $out (dict "name" "s3-ca" "secret" $s.s3CA.existingSecret "path" "/var/run/secrets/trove/s3-ca" "items" (list (dict "key" $s.s3CA.key "path" "ca.crt"))) -}}
{{- end -}}
{{- end -}}
{{- if $job -}}
{{- /* The backup target: its keys and its CA reach the Jobs that write or read it and no replica (R-HA-060, R-BAK-011). */ -}}
{{- if eq (dig "backup" "target" "credentials" "source" "default" .root.Values.config) "static" -}}
{{- $tItems := list (dict "key" $s.backupTarget.accessKeyIdKey "path" "access-key-id") (dict "key" $s.backupTarget.secretAccessKeyKey "path" "secret-access-key") -}}
{{- if $s.backupTarget.sessionTokenKey -}}
{{- $tItems = append $tItems (dict "key" $s.backupTarget.sessionTokenKey "path" "session-token") -}}
{{- end -}}
{{- $out = append $out (dict "name" "backup-target" "secret" $s.backupTarget.existingSecret "path" "/var/run/secrets/trove/backup-target" "items" $tItems) -}}
{{- end -}}
{{- if $s.backupTargetCA.existingSecret -}}
{{- $out = append $out (dict "name" "backup-target-ca" "secret" $s.backupTargetCA.existingSecret "path" "/var/run/secrets/trove/backup-target-ca" "items" (list (dict "key" $s.backupTargetCA.key "path" "ca.crt"))) -}}
{{- end -}}
{{- end -}}
{{- $jcSource := "runtime" -}}
{{- if eq .scope "post-restore" -}}{{- $jcSource = .root.Values.postRestore.journalCredentials.source -}}{{- end -}}
{{- if eq .scope "restore" -}}{{- $jcSource = .root.Values.restore.journalCredentials.source -}}{{- end -}}
{{- if eq $jcSource "static" -}}
{{- /* The credential that lists object versions, for the journal replay of the post-restore and the restore Job only (R-HA-025 step 5, R-BAK-015, R-HA-023); the runtime credential deliberately lacks it. */ -}}
{{- $out = append $out (dict "name" "journal-reader" "secret" $s.journalReader.existingSecret "path" "/var/run/secrets/trove/journal-reader" "items" (list (dict "key" $s.journalReader.accessKeyIdKey "path" "access-key-id") (dict "key" $s.journalReader.secretAccessKeyKey "path" "secret-access-key"))) -}}
{{- end -}}
{{- if eq .scope "runtime" -}}
{{- $vkItems := list -}}
{{- if $s.valkey.usernameKey -}}
{{- $vkItems = append $vkItems (dict "key" $s.valkey.usernameKey "path" "username") -}}
{{- end -}}
{{- $vkItems = append $vkItems (dict "key" $s.valkey.passwordKey "path" "password") -}}
{{- $out = append $out (dict "name" "valkey" "secret" $s.valkey.existingSecret "path" "/var/run/secrets/trove/valkey" "items" $vkItems) -}}
{{- if $s.valkeySentinel.existingSecret -}}
{{- $snItems := list -}}
{{- if $s.valkeySentinel.usernameKey -}}
{{- $snItems = append $snItems (dict "key" $s.valkeySentinel.usernameKey "path" "username") -}}
{{- end -}}
{{- $snItems = append $snItems (dict "key" $s.valkeySentinel.passwordKey "path" "password") -}}
{{- $out = append $out (dict "name" "valkey-sentinel" "secret" $s.valkeySentinel.existingSecret "path" "/var/run/secrets/trove/valkey-sentinel" "items" $snItems) -}}
{{- end -}}
{{- if $s.valkeyCA.existingSecret -}}
{{- $out = append $out (dict "name" "valkey-ca" "secret" $s.valkeyCA.existingSecret "path" "/var/run/secrets/trove/valkey-ca" "items" (list (dict "key" $s.valkeyCA.key "path" "ca.crt"))) -}}
{{- end -}}
{{- if $s.valkeyClientCert.existingSecret -}}
{{- $out = append $out (dict "name" "valkey-client" "secret" $s.valkeyClientCert.existingSecret "path" "/var/run/secrets/trove/valkey-client" "items" (list (dict "key" $s.valkeyClientCert.certKey "path" "tls.crt") (dict "key" $s.valkeyClientCert.keyKey "path" "tls.key"))) -}}
{{- end -}}
{{- /* The login secrets belong to the pods of role api (R-HA-030, R-AUTH-014, R-AUTH-042, Q-HA-79): the main Deployment, its pools and its endpoint pools, and the web pods of the bridge; never packages, worker or the migration Job. */ -}}
{{- if has (.role | default "") (list "api" "web") -}}
{{- range $s.oidc -}}
{{- $out = append $out (dict "name" (printf "oidc-%s" .providerId) "secret" .existingSecret "path" (printf "/var/run/secrets/trove/oidc-%s" .providerId) "items" (list (dict "key" (.key | default "client-secret") "path" "client-secret"))) -}}
{{- end -}}
{{- if $s.breakGlass.existingSecret -}}
{{- $out = append $out (dict "name" "break-glass" "secret" $s.breakGlass.existingSecret "path" "/var/run/secrets/trove/break-glass" "items" (list (dict "key" $s.breakGlass.key "path" "password"))) -}}
{{- end -}}
{{- end -}}
{{- if eq (dig "metrics" "auth" "" .root.Values.config) "static" -}}
{{- $out = append $out (dict "name" "metrics" "secret" $s.metricsToken.existingSecret "path" "/var/run/secrets/trove/metrics" "items" (list (dict "key" $s.metricsToken.key "path" "token"))) -}}
{{- end -}}
{{- /*
TLS material of the listeners (R-HA-063): only the pods whose process loads it; the Job serves no
listener. The listener pair of tls.secretName is read by the ops listener of every pod unless tls.ops
gives it its own pair, and by the client listener (the pods that open :8080: api, packages, their path
pools and the bridge's web pods) and by every further endpoint without a certificate of its own (the
pods that serve it). The client CA belongs to the client listener of the default endpoint only. A pod
that loads none of them does not get the private key.
*/ -}}
{{- $t := .root.Values.tls -}}
{{- if $t.enabled -}}
{{- $role := .role | default "" -}}
{{- $pool := .pool | default "" -}}
{{- $client := include "trove.opensDefault" (dict "role" $role "pool" $pool) | eq "true" -}}
{{- $mainPair := or $client (not $t.ops.secretName) -}}
{{- if and (ne $role "worker") (not $mainPair) -}}
{{- range $name := include "trove.unitEndpoints" (dict "root" .root "role" $role "pool" $pool) | fromYamlArray -}}
{{- $e := include "trove.endpoint" (dict "root" $.root "name" $name) | fromYaml -}}
{{- if not $e.tlsSecret -}}
{{- $mainPair = true -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if $mainPair -}}
{{- $out = append $out (dict "name" "tls" "secret" $t.secretName "path" "/var/run/secrets/trove/tls" "items" (list (dict "key" $t.certKey "path" "tls.crt") (dict "key" $t.keyKey "path" "tls.key"))) -}}
{{- end -}}
{{- if and $client $t.clientCA.secretName -}}
{{- $out = append $out (dict "name" "tls-client-ca" "secret" $t.clientCA.secretName "path" "/var/run/secrets/trove/tls-client-ca" "items" (list (dict "key" $t.clientCA.key "path" "ca.crt"))) -}}
{{- end -}}
{{- if $t.ops.secretName -}}
{{- $out = append $out (dict "name" "tls-ops" "secret" $t.ops.secretName "path" "/var/run/secrets/trove/tls-ops" "items" (list (dict "key" $t.ops.certKey "path" "tls.crt") (dict "key" $t.ops.keyKey "path" "tls.key"))) -}}
{{- end -}}
{{- end -}}
{{- /* The Secrets of the endpoints this pod serves (R-EP-004, R-EP-008); worker pods and the Job serve none. */ -}}
{{- $out = concat $out (include "trove.endpointSecretMounts" (dict "root" .root "role" (.role | default "") "pool" (.pool | default "")) | fromYamlArray) -}}
{{- end -}}
{{- toYaml $out -}}
{{- end -}}

{{- define "trove.secretVolumes" -}}
{{- range fromYamlArray (include "trove.secretMounts" .) }}
- name: secret-{{ .name }}
  {{- if .configMap }}
  configMap:
    name: {{ .configMap }}
    defaultMode: 0440
    items:
    {{- range .items }}
    - key: {{ .key }}
      path: {{ .path }}
    {{- end }}
  {{- else }}
  secret:
    secretName: {{ .secret }}
    defaultMode: 0440
    items:
    {{- range .items }}
    - key: {{ .key }}
      path: {{ .path }}
    {{- end }}
  {{- end }}
{{- end }}
{{- end -}}

{{- define "trove.secretVolumeMounts" -}}
{{- range fromYamlArray (include "trove.secretMounts" .) }}
- name: secret-{{ .name }}
  mountPath: {{ .path }}
  readOnly: true
{{- end }}
{{- end -}}
